//
//  secondViewController.swift
//  segundoExamenParcial
//
//  Created by Macbook on 5/23/19.
//  Copyright © 2019 DML_LRBL. All rights reserved.
//

import UIKit

class secondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func playerita(_ sender: Int)   {
        var num = sender
          num = 5
       play =  num
       
    
    }
    
    @IBOutlet weak var taz: UITextField!

    @IBOutlet weak var ta: UITextField!
    
    @IBAction func tacita(_ sender: Int) {
        var num2 = sender
        
         num2 = 3
     //taza = taz.hashValue
        taza = num2
       
    }
    
    
    @IBAction  func codigo(_ sender: Any) {
       // if let codi = sender  as! String{
        //if let codi = codigo(<#T##sender: Any##Any#>)
        let pl = (ta.text)!
        let tz = (taz.text)!
        var p = Int (pl)
        var t = Int (tz)
        let total = ((p! * 100) + (t! * 50))*(1/2)
        label2.text = "El total es \(total)"
    }
    
    
    @IBOutlet weak var codx: UITextField!
    @IBAction func compra(_ sender: Any) {
        
        //let total = ((ta.text)! + (taz.text)!)
        var cx = "COD"
        if  cx != codx.text{
        let pl = (ta.text)!
        let tz = (taz.text)!
        let p = Int(pl)
        let t = Int(tz)
        var total = ((p! * 100) + (t! * 50))//*(1/2)
        label2.text = "El total es \(total)"
        }
        else if cx == codx.text
        {
            let pl = (ta.text)!
            let tz = (taz.text)!
            var p = Int (pl)
            var t = Int (tz)
            var total = ((p! * 100) + (t! * 50))/2
            label2.text = "El total es \(total)"
            
            
        }
        }
        /*func textField(taz:Int ,ta: Int )
        {
            let total = (ta*100 + taz*50)
            //tot = Double(total)
            label2.text = "El total es \(total)"
        }
        textField(taz: play, ta: taza)
        let total = (play*100 + taza*50)
        tot = Double(total)
        label2.text = "El total es \(total)"
        */
    

    @IBOutlet weak var label2: UILabel!
}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


